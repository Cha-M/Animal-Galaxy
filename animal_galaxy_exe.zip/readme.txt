Extract the folder Animal Galaxy and run the .exe file from inside the folder. Python38.dll needs to be in the same folder as the .exe file.
-Sha